from SiemplifyUtils import output_handler
from SiemplifyAction import SiemplifyAction
import requests
import json
import time
from datetime import datetime

TASK_URL = '{}/external/v1/cases/AddOrUpdateCaseTask'
ACTION_NAME = "CreateNewTask"

@output_handler
def main():
    siemplify = SiemplifyAction()
    siemplify.script_name = ACTION_NAME
    

    assign_to = siemplify.parameters['Assign To']
    task_content = siemplify.parameters['Task Content']
    
    duration = siemplify.parameters['SLA (in minutes)']
    
    time_now = datetime.now()
    time_now_epoch = int(time.mktime(time_now.timetuple()))*1000
    client_time = time_now_epoch+(int(duration)*1000*60)
    
    case_id = siemplify.case_id

    json_payload = {"owner": assign_to, "name": task_content, "dueDate": "", "dueDateUnixTimeMs": client_time, "caseId":case_id}
    add_task = siemplify.session.post(TASK_URL.format(siemplify.API_ROOT), json=json_payload)
    add_task.raise_for_status()
   
    output_message = "A new task has been created for the user: {0}.\nThis task should be handled in the next {1} mintues".format(assign_to,duration)
    siemplify.end(output_message, True)

if __name__ == "__main__":
    main()