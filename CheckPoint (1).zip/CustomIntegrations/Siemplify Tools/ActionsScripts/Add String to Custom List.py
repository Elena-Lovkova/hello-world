from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import  output_handler, convert_dict_to_json_result_dict
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED
from SiemplifyDataModel import CustomList
import json

    
def get_custom_list_items(siemplify, category_name, input_string):
        """
        Get a list of custom list items from category and entities list.
        :param category_name: the custom list category
        :param entities: a list of entities
        :return: a list of custom list item objects
        """

        custom_list_items = []
        custom_list_items.append(
            CustomList(identifier=input_string, category=category_name, environment=siemplify.environment))
        return custom_list_items

def add_entities_to_custom_list(siemplify, custom_list_items):
        """
        Add the entities to the custom list with the given category.
        :param custom_list_items: a list of custom list items
        :return: {list}
        """
        custom_list_items_data = []
        for cli in custom_list_items:
            custom_list_items_data.append(cli.__dict__)

        address = "{0}/{1}".format(siemplify.API_ROOT, "external/v1/sdk/AddEntitiesToCustomList?format=snake")
        response = siemplify.session.post(address, json=custom_list_items_data)
        siemplify.validate_siemplify_error(response)
        custom_list_dicts = response.json()        

@output_handler
def main():
    siemplify = SiemplifyAction()
    
    try:
        status = EXECUTION_STATE_COMPLETED  
        output_message = "output message :" 
        result_value = 0 

        category = siemplify.parameters.get("Category")
        list_item = siemplify.parameters.get("ListItem")
        custom_list_items = get_custom_list_items(siemplify, category, list_item)
        json_result  = add_entities_to_custom_list(siemplify, custom_list_items)
        output_message = "Added {} to category {}".format(list_item, category)

    except Exception as e:
        raise
        status = EXECUTION_STATE_FAILED
        result_value = "Failed"
        output_message += "\n unknown failure"


    siemplify.end(output_message, True, status)


if __name__ == "__main__":
    main()
