from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import output_handler

SCRIPT_NAME = "FindFirstAlert"

@output_handler
def main():
    siemplify = SiemplifyAction()
    siemplify.script_name = SCRIPT_NAME
    if siemplify.current_alert.identifier == siemplify.case.alerts[-1].identifier:
        siemplify.end("First", siemplify.current_alert.identifier)
    siemplify.end("Not First", "false")


if __name__ == "__main__":
    main()
