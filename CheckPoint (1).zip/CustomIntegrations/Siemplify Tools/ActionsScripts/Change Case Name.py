from SiemplifyAction import *
import requests


def main():
    siemplify = SiemplifyAction()
    siemplify.script_name = "ChangeCaseName"
    
    outpu_message = ""
    result_value = "false"
    try:
        try:
            api_key = siemplify.api_key
        except:
            api_key = siemplify._api_key
        session = requests.session()
        session.verify = False
        change = True
        if siemplify.parameters.get('Only If First Alert', 'false').lower() == 'true':
            if siemplify.current_alert.identifier != siemplify.case.alerts[-1].identifier:
                change = False
        if change:
            session.headers = {'AppKey': api_key, 'Content-Type': 'application/json', 'Accept': 'application/json'}
            res = session.post('https://localhost:8443/api/external/v1/cases/RenameCase',
                               json={"caseId": siemplify.case_id, "title": siemplify.parameters['New Name']})
        
            res.raise_for_status()
        
            output_message = "Case's title changed to: {}".format(siemplify.parameters['New Name'])
            result_value = 'true'
        else:
            output_message = "Case's title not changed, not first alert in the case"
            result_value = 'true'
    except Exception as e:
        output_message = "An error occured: " + e.message
        siemplify.LOGGER.error(outpu_message)
        siemplify.LOGGER.exception(e)
    
    siemplify.end(output_message, result_value)


if __name__ == "__main__":
    main()