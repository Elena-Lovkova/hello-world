from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import output_handler

import json
import base64


    
def main():
    siemplify = SiemplifyAction()
    base64_input = siemplify.parameters.get("Base64 Input")
    encoding = 'ascii'#siemplify.parameters.get("Encoding")
    

    decoded_content = str(base64.b64decode(base64_input), encoding)
    result = {'decoded_content':decoded_content}
    
    siemplify.result.add_result_json(json.dumps(result))


    siemplify.end('Content was succesfully decoded from base 64 to string with encoding ' + encoding, True)




if __name__ == "__main__":
    main()
