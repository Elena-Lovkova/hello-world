from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import output_handler
import json
import uuid
import os


@output_handler
def main():
    siemplify = SiemplifyAction()
    
    
    case_data = siemplify._get_case()
    
    siemplify.result.add_result_json(case_data)
    
    siemplify.end("See technical details", json.dumps(case_data))


if __name__ == "__main__":
    main()

