from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
import json, re


@output_handler
def main():
    siemplify = SiemplifyAction()



    input = siemplify.parameters.get("Input")
    function = siemplify.parameters.get("Function")
    param_1 = siemplify.parameters.get("Param 1")
    param_2 = siemplify.parameters.get("Param 2")

    output_message = ''
    result = input
    
    if function == 'Lower':
        result = input.lower()
        output_message = '{0} successfully converted to {1} with lower function'.format(input,result)
    
    elif function == 'Upper':
        result = input.upper()
        output_message  = '{0} successfully converted to {1} with upper function'.format(input,result)
    
    elif function == 'Strip':
        result = input.strip()
        output_message  = '{0} successfully converted to {1} with strip function'.format(input,result)
    
    elif function == 'Title':
        result = input.title()
        output_message  = '{0} successfully converted to {1} with title function'.format(input,result)
       
    elif function == 'Count':
        result = input.count(param_1)
        output_message = "'{0}' was found {1} times in '{2}'".format(param_1,result, input)

    elif function == 'Replace':
        result = input.replace(param_1, param_2)
        output_message  = '{0} successfully converted to {1} with replace function'.format(input,result)
        
    elif function == 'Find':
        result = input.find(param_1)
        output_message = "'{0}' was found at index {1} in '{2}'".format(param_1,result, input)
    
    elif function == 'Upper':
        result = input.upper()
        output_message  = '{0} successfully converted to {1} with upper function'.format(input,result)
    
    elif function == 'IsAlpha':
        result = input.isalpha()
        print(result)
        if(result):
            output_message = "All characters in {0} are alphanumeric".format(input)
        else:
            output_message = "Not all characters in {0} are alphanumeric".format(input)
    
    elif function == 'IsDigit':
        result = input.isdigit()
        print(result)
        if(result):
            output_message = "All characters in {0} are digits".format(input)
        else:
            output_message = "Not all characters in {0} are digits".format(input)  
    
    elif function == 'Regex Replace':
        result = re.sub(param_1, param_2, input)
        output_message  = '{0} successfully converted to {1} with regex replace function'.format(input,result)
    
    elif function == 'JSON Serialize':
        result = json.dumps(input)
        output_message = "{} successfully serialized to JSON format".format(input)
    
    elif function == 'Regex':
        if not param_2:
            param_2 = ", "
        result = param_2.join(re.findall(param_1, input))
        output_message = "Found following values:\n{}".format(result)
    
    siemplify.end(output_message, result, EXECUTION_STATE_COMPLETED)


if __name__ == "__main__":
    main()
