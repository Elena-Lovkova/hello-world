from SiemplifyUtils import output_handler
import json
from SiemplifyAction import SiemplifyAction
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED

# CONSTS:
ENTITY_IDENTIFIER_FIELD_NAME = "Entity"
JSON_DATA_FIELD_NAME = "EntityResult"
MULTIPLE_VALUES = "MULTIPLE VALUES FOUND"
MISSING_VAL = "NotFound"
NOT_SIMPLE_VAL = "Value is a dict"
NOT_FOR_TABLE = "NO_TABLE"

def GetIdentifiersAsString(target_entities):
    entitiesIdentifiers = []
    for entity in target_entities:
        entitiesIdentifiers.append(entity.identifier)
    return ", ".join(entitiesIdentifiers)

def GetEntityByString(identifier, entities):
    for ent in entities:
        if identifier.lower() == ent.identifier.lower():
            return ent
    return None

def process_trios(trio_list):
    bad_json = []
    insight_data = []
    for trio in trio_list:
        if trio.get("title") : # We expect some values here
            data_obj = {}
            data_obj["title"] = trio.get("title")
            try:
                data_obj["fields"] = process_fields_string(trio.get("fields"))
            except Exception as e:
                raise Exception("Syntax error. Error message is: {}".format(e))
            try:
                data_obj["json"] = trio.get("json")
            except:
                bad_json.append(data_obj)
                continue
            insight_data.append(data_obj)
    
    return insight_data, bad_json

def process_fields_string(fields_list):
    """
    Gets a string of the format: "Count:path1.path2.length,RISK:path3.path4.risk_score"
    and breaks it into list of objects: {"display": STRING, "key_path": STRING(path1.path2.path3)}
    
    Key characters: "," and ":". ":" marks the separation between display and path where "," marks separation between fields
    """
    if not fields_list:
        return []
    
    fields_data = []
    #raise Exception(json.dumps(field_string))
    for item in fields_list:
        field_item = {}
        field_item["key_path"] = item["XPath"]
        if item["Display"]:
            field_item["display"] = item["Display"]
        else:
            field_item["display"] = NOT_FOR_TABLE
        field_item["format_string"] = item.get("FormatString", "{}")
        fields_data.append(field_item)
    
    # field_string = field_string.replace(u"\n", u",")
    # for field_rep in field_string.split(","):
    #     if field_rep.strip(): # Ignore empty
    #         temp = field_rep.strip().split(":")
    #         display = temp[0]
    #         if len(temp) == 1:
    #             key_path = temp[0].split(".")
    #             fields_data.append({"display": NOT_FOR_TABLE, "key_path": key_path})
    #             continue
    #             #raise Exception("Field definition missing ':'. Field: {}".format(field_rep))
    #         elif len(temp) != 2:
    #             raise Exception("General issue with the formating of the field: {}".format(json.dumps(field_rep)))
    #         key_path = temp[1].split(".")
    #         fields_data.append({"display": display.strip(), "key_path": [x.strip() for x in key_path]})
    return fields_data

def extract_json_based_on_entity(entity, json_data):
    try:
        if not isinstance(json_data, list):
            return None
        
        for item in json_data: # Assuming regular list format for enrichment actions
            if item[ENTITY_IDENTIFIER_FIELD_NAME].lower() == entity.identifier.lower():
                return item[JSON_DATA_FIELD_NAME]
    except:
        raise Exception(json_data)
    return None

def find_key_path_in_json(key_path, json_data):
    """
    Finds the relevant key_path in a json object. 
    If list encountered, if its of len 1, its value is used. Otherwise, it exits with default value (MULTIPLE VALUES FOUND)
    """
    return find_key_path_recursive(key_path, json_data)
    
def find_key_path_recursive(key_list, current_json):
    if key_list:
        if isinstance(current_json, list):
            if key_list:
                if len(current_json) == 1:
                    return find_key_path_recursive(key_list, current_json[0])
                else:
                    return MULTIPLE_VALUES
            return ", ".join(current_json)
        if isinstance(current_json, dict):
            if key_list[0] in current_json:
                return find_key_path_recursive(key_list[1:], current_json[key_list[0]])
            # raise Exception("Key: {}, json: {}".format(key_list, current_json))
            return MISSING_VAL
    else:
        if isinstance(current_json, dict):
            return NOT_SIMPLE_VAL
        if isinstance(current_json, list):
            ret_list = []
            for item in current_json:
                if isinstance(item, dict) or isinstance(item, list):
                    return NOT_SIMPLE_VAL
                ret_list.append(item) 
            return u",".join(ret_list)
        
        return u"{}".format(current_json) # Found val, return it. Format to make everything into string
    

def fix_json_string(json_string, unique_marker_string):
    if not unique_marker_string:
        return json_string
    
    to_return = ""
    chunks = json_string.split(unique_marker_string)
    if len(chunks) % 2 == 0: # Odd number of chunks
        raise Exception("Uneven amount of JSON separators")
    i = 1
    to_return += chunks[0]
    while i + 1 < len(chunks):
        to_return += json.dumps(chunks[i])
        to_return += chunks[i+1]
        i += 2
    return to_return

@output_handler
def main():
    siemplify = SiemplifyAction()
    
    added_insights = []
    
    input_trios = []
    
    try:
        in_json = fix_json_string(siemplify.parameters.get("JSON_DATA"), siemplify.parameters.get("JSON Marker"))
        json_data_input = json.loads(in_json)
        # for i in range(1,8):
        #     input_trios.append({"title": siemplify.parameters.get('Title{}'.format(i)), 
        #                         "fields": siemplify.parameters.get('Fields{}'.format(i)), 
        #                         "json": siemplify.parameters.get('JSON{}'.format(i))
        #     })
        for item in json_data_input:
            trio = {}
            trio["title"] = item["TriggeredBy"]
            try:
                trio["json"] = json.loads(item["JSON"])
            except:
                trio["json"] = item["JSON"]
            trio["fields"] = item["Fields"]
            input_trios.append(trio)
        # raise Exception(input_trios)
        processed_trios, bad_trios = process_trios(input_trios)
        
        for ent in siemplify.target_entities:
            found_at_least_one_value = False
            insight_message_list = []
            insight_message = u""
            for trio in processed_trios:
                trio_message_list = []
                not_for_tables = []
                json_data = extract_json_based_on_entity(ent, trio["json"])
                if json_data:
                    for item in trio.get("fields", []):
                        display = item["display"]
                        key_path = item["key_path"]
                        
                        val = find_key_path_in_json(key_path, json_data)
                        if val:
                            found_at_least_one_value = True
                            try:
                                val = item["format_string"].format(val)
                            except:
                                val = val # Skip the format string
                        new_item = {"display": display, "value": val}
                        if display == NOT_FOR_TABLE:
                            not_for_tables.append(new_item)
                        else:
                            trio_message_list.append(new_item)
                    
                    if found_at_least_one_value:
                        trio_message_list = [x for x in trio_message_list if x["value"] != MISSING_VAL] + \
                                            [{"display": "", "value": ""}] + \
                                            [x for x in trio_message_list if x["value"] == MISSING_VAL]
                        
                        rows_list = ["""<td><strong>{display}</strong></td><td>{value}</td></tr>""".format(**trio_message_item) for trio_message_item in trio_message_list]
                        rows = "".join(rows_list)
                        
                        trio_message = u"""<table border="1" width="290"><tbody><tr>{rows}<tr></tbody></table>""".format(
                             rows=rows)
                        
                        title_message_list = []
                        not_for_tables_message = []
                        if not_for_tables:
                            not_for_tables_message = u"<br>".join([x["value"] for x in not_for_tables])
                            title_message_list.append(not_for_tables_message)
                        if trio_message:
                            title_message_list.append(trio_message)
                        
                        title_message = u"<br>".join([x for x in [trio_message, not_for_tables_message] if x])
                        siemplify.add_entity_insight(ent, title_message, triggered_by=trio.get("title"))
                        insight_message_list.append(title_message)
                        added_insights.append(ent)
                    else:
                        pass # No need for insight if no field returned with data
                else:
                    pass  # No need for insight incase there is no data for entity
                    # title_message = """Not Found"""
                    # insight_message_list.append(title_message)
                    # siemplify.add_entity_insight(ent, title_message, triggered_by=trio.get("title"))
            
                
            if bad_trios:
                insight_message += u"<br><br>"
                insight_message += u"<br><br>".join([u"""JSON Completly missing or badly formatted""".format(
                        trio.get('title')) for trio in bad_trios])
                for trio in bad_trios:
                    title_message = """JSON Completly missing or badly formatted"""
                    siemplify.add_entity_insight(ent, title_message, triggered_by=trio.get("title"))
    
            
    
        output_message = u"Insight added to following entities: {}".format(",".join([x.identifier for x in added_insights]))
    
        siemplify.end(output_message, 'true')
    except Exception as e:
        #raise
        siemplify.end("Errors found: {}".format(e), 'Failed', EXECUTION_STATE_FAILED)


if __name__ == '__main__':
    main()
    