from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT



@output_handler
def main():
    siemplify = SiemplifyAction()

    scope = siemplify.extract_action_param("Scope")
    key = siemplify.extract_action_param("Key")
    
    result_value = None
    
    if scope == 'Alert':
        result_value = siemplify.get_alert_context_property(key)
    
    elif scope == 'Case':
        result_value = siemplify.get_case_context_property(key)

    output_message = "Not found value for key: {0} in scope {1} :".format(key,scope)

    if result_value:
        output_message = "Successfully found '{0}' for key: {1} in scope {2}.".format(result_value,key,scope)

    siemplify.end(output_message, result_value, EXECUTION_STATE_COMPLETED)

if __name__ == "__main__":
    main()
