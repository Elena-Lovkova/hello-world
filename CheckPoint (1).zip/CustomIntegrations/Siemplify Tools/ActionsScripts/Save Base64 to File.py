from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
import errno
import json
import base64
import os
import re


INTEGRATION_NAME = u"Siemplify Tools"
SCRIPT_NAME = u"Save Base64 to File"
LOCAL_FOLDER = u"downloads"

def get_valid_filename(s):
    s = str(s).strip().replace(' ', '_')
    return re.sub(r'(?u)[^-\w.]', '', s)
    
    
def main():
    siemplify = SiemplifyAction()
    siemplify.script_name = SCRIPT_NAME
    base64_inputs = filter(None, [x.strip() for x in siemplify.parameters.get("Base64 Input").split(',')])
    filenames = filter(None, [x.strip() for x in siemplify.parameters.get("Filename").split(',')])
    file_extension = siemplify.parameters.get("File Extension")
    folder_path = os.path.join(siemplify.RUN_FOLDER, LOCAL_FOLDER)
    json_results = {}
    json_results['files'] = []
    file_paths = []
    try:
        os.makedirs(folder_path)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise
    for filename, base64_input in zip(filenames, base64_inputs):
        file_path = os.path.join(folder_path, get_valid_filename(filename))
        if file_extension:
            file_path = file_path + "." + file_extension
        try:
            with open(file_path, "wb") as fh:
                fh.write(base64.b64decode(base64_input))
        except Execption as e:
            siemplify.LOGGER.error("Error: {}".format(e))
            raise
        file_paths.append(file_path)
        filedets = {}
        filedets['file_name'] = filename
        filedets['file_path'] = file_path
        json_results['files'].append(filedets)
    
    
    status = EXECUTION_STATE_COMPLETED
    siemplify.result.add_result_json(json.dumps(json_results))
    output_message = 'Saved the base64 images to: ' + ",".join(file_paths)
    siemplify.end(output_message, True, status)

if __name__ == "__main__":
    main()
