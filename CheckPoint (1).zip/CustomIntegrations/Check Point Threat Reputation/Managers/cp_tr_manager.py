import requests 

class CheckPoint_TR_Manager(): 
    def __init__(self, 
                    client_key, 
                    api_root="https://rep.checkpoint.com",
                    verify_ssl=True):
        self.client_key = client_key
        self.api_root = api_root
        self.get_token()
        self.auth_headers = {
            "Client-Key": self.client_key,
            "token": self.token,
            "Content-Type": "application/json",
            "accept": "application/json"
        }
        self.session = requests.Session()
        self.session.headers = self.auth_headers
        self.session.verify = verify_ssl
    
    def get_token(self):
        url = "{}/rep-auth/service/v1.0/request".format(self.api_root)
        res = requests.get(url, headers={"Client-Key": self.client_key})
        res.raise_for_status()
        
        self.token = res.content
    
    def get_url_rep(self, ioc): 
        req = self.session.post(url="{}/url-rep/service/v2.0/query".format(self.api_root), 
                            params={"resource":ioc},
                            json={"request":[{"resource":ioc}]}, 
                            headers=self.auth_headers)
        return req.json()
        
    def get_ip_rep(self, ioc): 
        req = self.session.post(url="{}/ip-rep/service/v2.0/query".format(self.api_root), 
                            params={"resource":ioc},
                            json={"request":[{"resource":ioc}]}, 
                            headers=self.auth_headers)
        return req.json()
    
    def get_file_rep(self, ioc): 
        req = self.session.post(url="{}/file-rep/service/v2.0/query".format(self.api_root), 
                            params={"resource":ioc},
                            json={"request":[{"resource":ioc}]}, 
                            headers=self.auth_headers)
        return req.json()
        
    def ping(self):
        try:
            req = self.session.post(url="{}/url-rep/service/v2.0/query".format(self.api_root), 
                            params={"resource":"https://www.google.com"},
                            json={"request":[{"resource":"https://www.google.com"}]}, 
                            headers=self.auth_headers)
            if req.status_code < 300 and req.status_code >= 200: 
                req.json()
                return 'true'
            else: 
                return 'false'
        except Exception as e: 
            return 'false'
        