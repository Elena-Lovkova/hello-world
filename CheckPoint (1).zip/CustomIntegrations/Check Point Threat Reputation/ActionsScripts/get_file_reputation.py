from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
from SiemplifyDataModel import EntityTypes
from cp_tr_manager import CheckPoint_TR_Manager
# Example Consts:
INTEGRATION_NAME = "Check Point Threat Reputation"

SCRIPT_NAME = "get_file_reputation"

@output_handler
def main():
    siemplify = SiemplifyAction()
    siemplify.script_name = SCRIPT_NAME
    siemplify.LOGGER.info("[ INFO ] ================= Main - Param Init =================")

    # INIT INTEGRATION CONFIGURATION:
    client_key = siemplify.extract_configuration_param(provider_name=INTEGRATION_NAME,
                                                    param_name="Client Key")
    api_root = siemplify.extract_configuration_param(provider_name=INTEGRATION_NAME,
                                                    param_name="API Root")
                                                    
    cp_manager = CheckPoint_TR_Manager(client_key=client_key, api_root=api_root)
    confidence_threshold = 0
    
    siemplify.LOGGER.info("[ INFO ] ----------------- Main - Started -----------------")
    try:
        status = EXECUTION_STATE_COMPLETED  # used to flag back to siemplify system, the action final status
        output_message = "output message :"  # human readable message, showed in UI as the action result
        result_value = None  # Set a simple result value, used for playbook if\else and placeholders.
        failed_entities = []  # In case this actions contains entity based logic, collect failed entity.identifiers
        successfull_entities = []  # In case this actions contains entity based logic, collect successfull entity.identifiers
        white_list_class = ["Benign", "Unclassified"]

        for entity in siemplify.target_entities:
            siemplify.LOGGER.info("[ INFO ] Started processing entity: {}".format(entity.identifier))
            if unix_now() >= siemplify.execution_deadline_unix_time_ms:
                siemplify.LOGGER.error("[ ERROR ] Timed out. execution deadline ({}) has passed".format(convert_unixtime_to_datetime(siemplify.execution_deadline_unix_time_ms)))
                status = EXECUTION_STATE_TIMEDOUT
                break
            if entity.entity_type == EntityTypes.FILEHASH:
                try:
                    print("Attempting to fetch file data")
                    rep_data = cp_manager.get_file_rep(entity.identifier)['response'][0]
                    rep_data_string = """Classification: {}
                                        Confidence: {}
                                        Severity: {}
                                        Risk: {}
                                        """.format(rep_data['reputation']['classification'],
                                                    rep_data['reputation']['confidence'],
                                                    rep_data['reputation']['severity'],
                                                    rep_data['risk'])
                    try:
                        indications = "\n".join(rep_data['context']['indications'])
                        rep_data_string = rep_data_string + "\n" + indications
                    except Exception as e: 
                        print("No indications insight added.")
                    siemplify.add_entity_insight(entity, rep_data_string)
                    entity.additional_properties.update(rep_data['reputation'])
                    entity.is_enriched = True
                    siemplify.result.add_result_json(rep_data)
                    if rep_data['risk'] > confidence_threshold and rep_data['reputation']['classification'] not in white_list_class:
                        print('Entity {} found to be suspicious (!!!)'.format(entity.identifier))
                        entity.is_suspicious = True
                    else: 
                        entity.is_suspicious = False
                        print('Entity {} NOT found to be suspicious'.format(entity.identifier))
                    # .... CUSTOM ENTITY BASED LOGIC HERE....
                    successfull_entities.append(entity)
                    siemplify.LOGGER.info("[ INFO ] Finished processing entity {0}".format(entity.identifier))
                    pass
                except Exception as e:
                    failed_entities.append(entity.identifier)
                    print(e)
                    siemplify.LOGGER.error("[ ERROR ] An error occurred on entity {0}".format(entity.identifier))
                    siemplify.LOGGER.exception(e)
            else:
                siemplify.LOGGER.info("[ INFO ] Skipping entity {} - not a URL".format(entity.identifier))

        if successfull_entities:
            siemplify.update_entities(successfull_entities)
            output_message += "\n Successfully processed entities:\n   {}".format("\n   ".join(list(map(lambda x: x.identifier, successfull_entities))))
        else:
            output_message += "\n No entities where processed."

        # Set a simple result value, used for playbook if\else and placeholders. Can be of any type (bool, string, number), and used for any desire
        # As an exmaple of arbitrary logic, we passed here the number of successfull processed entities - again, it's just an example.
        result_value = len(successfull_entities)

        if failed_entities:
            output_message += "\n Failed processing entities:\n   {}".format("\n   ".join(failed_entities))
            status = EXECUTION_STATE_FAILED

    except Exception as e:
        siemplify.LOGGER.error("[ ERROR ] General error performing action {}".format(SCRIPT_NAME))
        siemplify.LOGGER.exception(e)
        raise  # used to return entire error details - including stacktrace back to client UI. Best for most usecases
        # in case you want to handle the error yourself, don't raise, and handle error result ouputs:
        status = EXECUTION_STATE_FAILED
        result_value = "Failed"
        output_message += "\n unknown failure"


    siemplify.LOGGER.info("[ INFO ] ----------------- Main - Finished -----------------")
    siemplify.LOGGER.info("[ INFO ] \n  status: {}\n  result_value: {}\n  output_message: {}".format(status,result_value, output_message))
    siemplify.end(output_message, result_value, status)


if __name__ == "__main__":
    main()
