from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
from SiemplifyDataModel import EntityTypes
from cp_tr_manager import CheckPoint_TR_Manager
# Example Consts:
INTEGRATION_NAME = "Check Point Threat Reputation"

SCRIPT_NAME = "get_file_reputation"

@output_handler
def main():
    siemplify = SiemplifyAction()
    siemplify.script_name = SCRIPT_NAME
    siemplify.LOGGER.info("[ INFO ] ================= Main - Param Init =================")

    # INIT INTEGRATION CONFIGURATION:
    client_key = siemplify.extract_configuration_param(provider_name=INTEGRATION_NAME,
                                                    param_name="Client Key")
    api_root = siemplify.extract_configuration_param(provider_name=INTEGRATION_NAME,
                                                    param_name="API Root")
                                                    
    cp_manager = CheckPoint_TR_Manager(client_key=client_key, api_root=api_root)
    
    siemplify.LOGGER.info("[ INFO ] ----------------- Main - Started -----------------")
    try:
        status = EXECUTION_STATE_COMPLETED  # used to flag back to siemplify system, the action final status
        output_message = "output message :"  # human readable message, showed in UI as the action result
        result_value = None  # Set a simple result value, used for playbook if\else and placeholders.
        
        result_value = cp_manager.ping()

    except Exception as e:
        siemplify.LOGGER.error("[ ERROR ] General error performing action {}".format(SCRIPT_NAME))
        siemplify.LOGGER.exception(e)
        raise  # used to return entire error details - including stacktrace back to client UI. Best for most usecases
        # in case you want to handle the error yourself, don't raise, and handle error result ouputs:
        status = EXECUTION_STATE_FAILED
        result_value = "Failed"
        output_message += "\n unknown failure"


    siemplify.LOGGER.info("[ INFO ] ----------------- Main - Finished -----------------")
    siemplify.LOGGER.info("[ INFO ] \n  status: {}\n  result_value: {}\n  output_message: {}".format(status,result_value, output_message))
    siemplify.end(output_message, result_value, status)


if __name__ == "__main__":
    main()
