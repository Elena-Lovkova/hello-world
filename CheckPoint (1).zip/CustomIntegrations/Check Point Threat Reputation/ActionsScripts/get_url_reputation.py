from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler, convert_dict_to_json_result_dict, add_prefix_to_dict
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
from SiemplifyDataModel import EntityTypes
from cp_tr_manager import CheckPoint_TR_Manager

import json, copy
# Example Consts:
INTEGRATION_NAME = "Check Point Threat Reputation"

SCRIPT_NAME = "get_url_reputation"

def get_unicode(u):
    return str(u)

def dict_to_flat(target_dict):
    """
    Receives nested dictionary and returns it as a flat dictionary.
    :param target_dict: {dict}
    :return: Flat dict : {dict}
    """
    target_dict = copy.deepcopy(target_dict)

    def expand(raw_key, raw_value):
        key = raw_key
        value = raw_value
        """
        :param key: {string}
        :param value: {string}
        :return: Recursive function.
        """
        if value is None:
            return [(get_unicode(key), u"")]
        elif isinstance(value, dict):
            # Handle dict type value
            return [(u"{0}_{1}".format(get_unicode(key),
                                       get_unicode(sub_key)),
                     get_unicode(sub_value)) for sub_key, sub_value in dict_to_flat(value).items()]
        elif isinstance(value, list):
            # Handle list type value
            count = 1
            l = []
            items_to_remove = []
            for value_item in value:
                if isinstance(value_item, dict):
                    # Handle nested dict in list
                    l.extend([(u"{0}_{1}_{2}".format(get_unicode(key),
                                                     get_unicode(count),
                                                     get_unicode(sub_key)),
                               sub_value)
                              for sub_key, sub_value in dict_to_flat(value_item).items()])
                    items_to_remove.append(value_item)
                    count += 1
                elif isinstance(value_item, list):
                    l.extend(expand(get_unicode(key) + u'_' + get_unicode(count), value_item))
                    count += 1
                    items_to_remove.append(value_item)

            for value_item in items_to_remove:
                value.remove(value_item)

            for value_item in value:
                l.extend([(get_unicode(key) + u'_' + get_unicode(count), value_item)])
                count += 1

            return l
        else:
            return [(get_unicode(key), get_unicode(value))]

    items = [item for sub_key, sub_value in target_dict.items() for item in
             expand(sub_key, sub_value)]
    return dict(items)

@output_handler
def main():
    siemplify = SiemplifyAction()
    siemplify.script_name = SCRIPT_NAME
    siemplify.LOGGER.info("[ INFO ] ================= Main - Param Init =================")

    # INIT INTEGRATION CONFIGURATION:
    client_key = siemplify.extract_configuration_param(provider_name=INTEGRATION_NAME,
                                                    param_name="Client Key")
    api_root = siemplify.extract_configuration_param(provider_name=INTEGRATION_NAME,
                                                    param_name="API Root")
                                                    
    cp_manager = CheckPoint_TR_Manager(client_key=client_key, api_root=api_root)
    confidence_threshold = 0
    
    siemplify.LOGGER.info("[ INFO ] ----------------- Main - Started -----------------")
    try:
        status = EXECUTION_STATE_COMPLETED  # used to flag back to siemplify system, the action final status
        output_message = "output message :"  # human readable message, showed in UI as the action result
        result_value = None  # Set a simple result value, used for playbook if\else and placeholders.
        failed_entities = []  # In case this actions contains entity based logic, collect failed entity.identifiers
        successfull_entities = []  # In case this actions contains entity based logic, collect successfull entity.identifiers
        white_list_class = ["Benign", "Unclassified"]
        
        error_messages = []
        json_result = {}

        for entity in siemplify.target_entities:
            siemplify.LOGGER.info("[ INFO ] Started processing entity: {}".format(entity.identifier))
            if entity.entity_type == EntityTypes.URL:
                try:
                    rep_data = cp_manager.get_url_rep(entity.identifier)['response'][0]
                    rep_data_string = """Classification: {}
                                        Confidence: {}
                                        Severity: {}
                                        Risk: {}
                                        """.format(rep_data['reputation']['classification'],
                                                    rep_data['reputation']['confidence'],
                                                    rep_data['reputation']['severity'],
                                                    rep_data['risk'])
                    try:
                        indications = "\n".join(rep_data['context']['indications'])
                        rep_data_string = rep_data_string + "\n" + indications
                    except Exception as e: 
                        # print("No indications insight added.")
                        pass
                    siemplify.add_entity_insight(entity, rep_data_string)
                    # siemplify.result.add_result_json(rep_data)
                    json_result[entity.identifier] = rep_data
                    
                    entity.additional_properties.update(add_prefix_to_dict(dict_to_flat(rep_data['reputation']), "CP_ThreatReputation"))
                    if rep_data['risk'] > confidence_threshold and rep_data['reputation']['classification'] not in white_list_class:
                        entity.is_suspicious = True

                    successfull_entities.append(entity)
                except Exception as e:
                    failed_entities.append(entity.identifier)
                    error_messages.append("{}: {}".format(entity.identifier, str(e)))

        if successfull_entities:
            siemplify.update_entities(successfull_entities)
            output_message += "\nSuccessfully processed entities:\n   {}".format("\n   ".join(list(map(lambda x: x.identifier, successfull_entities))))
        else:
            output_message += "\nNo entities where processed."

        result_value = len(successfull_entities)

        if failed_entities:
            output_message += "\nFailed processing entities:\n   {}".format("\n   ".join(failed_entities))
            output_message += "\nErrors: {}".format(", ".join(error_messages))
            if not successfull_entities:
                status = EXECUTION_STATE_FAILED

    except Exception as e:
        siemplify.LOGGER.error("[ ERROR ] General error performing action {}".format(SCRIPT_NAME))
        siemplify.LOGGER.exception(e)
        raise  # used to return entire error details - including stacktrace back to client UI. Best for most usecases
        # in case you want to handle the error yourself, don't raise, and handle error result ouputs:
        status = EXECUTION_STATE_FAILED
        result_value = "Failed"
        output_message += "\n unknown failure"


    siemplify.end(output_message, result_value, status)


if __name__ == "__main__":
    main()
