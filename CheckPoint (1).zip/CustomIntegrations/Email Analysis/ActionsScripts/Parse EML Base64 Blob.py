from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import output_handler
import eml_parser, json, datetime


import base64, re
from email import message_from_string

def json_serial(obj):
    if isinstance(obj, datetime.datetime):
        serial = obj.isoformat()
        return serial
    if isinstance(obj, bytes):
        return obj.decode("utf-8")


@output_handler
def main():
    siemplify = SiemplifyAction()
    
    base64_blob = siemplify.parameters.get("Base64 EML Blob")
    eml_content = base64.b64decode(base64_blob)
    
    ep = eml_parser.EmlParser(include_raw_body=True, include_attachment_data=True)
    parsed_eml = ep.decode_email_bytes(eml_content)
    
    # print(json.dumps(parsed_eml, default=json_serial))
    siemplify.result.add_result_json(json.dumps(parsed_eml, default=json_serial))
    siemplify.end("Prased EML. See JSON.", "True")
    
    

if __name__ == "__main__":
    main()
