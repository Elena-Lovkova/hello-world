import requests 
import copy
import hashlib
import json
from pprint import pprint

from io import BytesIO
import base64
from requests_toolbelt import MultipartEncoder

# Append the api name at the end valid values: query/download/upload/quota
# api_url = "https://te.checkpoint.com/tecloud/api/v1/file/"

# headers = {'Authorization':api_key, 
#             'te_cookie':'remember', 
#             'Content-Type':'application/json'}
            
class SandBlast_Manager(): 
    def __init__(self, api_key, url="https://te.checkpoint.com/tecloud/api/v1/file/"):
        self.headers = {'Authorization':api_key, 
            'te_cookie':'remember', 
            'Content-Type':'application/json'}
        self.url = url
        
    def md5_hash_file(self, file_path): 
        with open(file_path, 'rb') as f:
            hasher = hashlib.md5()
            hasher.update(file)
            file_hash = hasher.hexdigest()
            f.close()
            return file_hash
        
    def determine_hash_type(self, file_hash): 
        # The three hash types supported by checkpoint as of 3/30/20
        if len(file_hash) == 32: return "md5"
        elif len(file_hash) == 64: return "sha256"
        elif len(file_hash) == 40: return "sha1"
        else: 
            print("Unknown hash submitted, length is {}, which is not md5, sha256, nor sha1".format(len(file_hash)))
            return None         
            
    def get_file_name(self, file_path): 
        if "\\" in file_path: 
            return file_path.split("\\")[-1]
        elif "/" in file_path: 
            return file_path.split("/")[-1]
        else: return None
        
    def upload_v2(self, file_path): 
        print("Uploading file")
        
        file_name = self.get_file_name(file_path)
        
        msg = "Error - no response from server or file at specified file path did not open."
        
        with open(file_path, 'r') as f: 
            request = {
                "request": {
                    "file_name":file_name,
                    "features": ["av", "te"],
                    "te": {"reports":["pdf","xml"]}
                }
            }
            req = requests.post(url=self.url + "upload", files = {'file':(f), 'request':json.dumps(request)})
            msg = req.text
        
        return msg 
        
    
    def upload(self, file_base64, file_name="untitled.doc"):
        raw_file = base64.b64decode(file_base64) # Got it in bytes
        
        if not file_name:
            file_name = "untitled.doc"
        
        # Calculate hash
        hasher = hashlib.md5()
        hasher.update(raw_file)
        file_hash = hasher.hexdigest()
        hash_type = "md5"
        
        # Stream object of the file instead of reading from disk
        f = BytesIO(raw_file)
        # with open("temp.txt", 'wb') as f:
            # f.write(raw_file)
        # with open("temp.txt", "rb") as f:
        headers = copy.copy(self.headers)
        del(headers['te_cookie'])
        payload = {
            "request": [
                {
                    "features": [
                        "te",
                        "extraction",
                        "av"
                        ],
                    "file_name": file_name, 
                    hash_type: file_hash, 
                    # "file_type": file_type,
                    "te": {"reports": ["xml", "summary"], "images":[{"id":"10b4a9c6-e414-425c-ae8b-fe4dd7b25244", "revision":1}]},
                    "extraction": {"method":"pdf"}
                }
            ]
        }
        # raise Exception(json.dumps(payload, indent=4))
        
        form = MultipartEncoder({
                    "request": json.dumps(payload),
                    "file": f,
                })
        headers["Content-Type"] = form.content_type
        req = requests.post(self.url + "upload", headers=headers, data=form)
        req.raise_for_status()
        
        try: 
            res = req.json()["response"]
            return {"result": res, "file_hash": file_hash}
        except: 
            raise Exception(req.content)
    
    # This should submit a file to the api, wait for it to detonate, then pull the results and return them in one api call 
    def upload_old(self, file_path, file_hash=None): 
        print("Uploading file to threat emulation") 
        
        if "\\" in file_path: 
            file_name = file_path.split("\\")[-1]
        elif "/" in file_path: 
            file_name = file_path.split("/")[-1]
           
        file_type = file_name.split(".")[1]

        file = None
        
        with open(file_path, 'rb') as f: 
            file = f.read()
            
        if file_hash is None: 
            hasher = hashlib.md5()
            hasher.update(file)
            file_hash = hasher.hexdigest()
            f.close()
            hash_type = "md5"
        else:
            hash_type = self.determine_hash_type(file_hash)
            if hash_type == None: return "Error - no hash type not sha256, md5, nor sha1 due to hash length being incorrect."
        
        print("File name - {} \nFile type - {} \nHash type - {} \nHash Value - {}\nFile Path - {}".format(file_name,file_type,hash_type,file_hash,file_path))
        
        with open(file_path, 'rb') as f: 
            #pprint(file_payload)
            headers = copy.copy(self.headers)
            del headers['te_cookie']
            # headers["Content-Type"] = "multipart/form-data; boundary=12345678912345678912345678"
            
            # payload template 
            # TODO: Add automatic imaging detection and inclusion in the payload
            payload =  {
                "request": [
                    {
                        "features": ["te", "extraction"],
                        "file_name": file_name, 
                        hash_type: file_hash,
                        "file_type": "txt",
                        "te": {"reports": ["xml", "summary"], "images":[{"id":"10b4a9c6-e414-425c-ae8b-fe4dd7b25244", "revision":1}]},
                        "extraction": {"method":"pdf"}
                        
                    }
                ]
            }
            
            # We add the hash value with the appropriate hash type as the key 
            # payload["request"][0][hash_type] = file_hash
            print("\n")
            
            pprint(payload)
            print("\n")
            pprint(headers)
            print("\n")
            file_payload = {"file":(file_name, f, "application/json"), "request": (None, json.dumps(payload), "application/json")}
            
            form = MultipartEncoder({
                        "request": json.dumps(payload),
                        "file": f,
                    })
            headers["Content-Type"] = form.content_type
            req = requests.post(self.url + "upload", headers=headers, data=form)
            req.raise_for_status()
            # raise Exception(req.status_code)
            
            # We post the request and return the results 
            # req = requests.post(url = self.url + "upload", headers=headers, files=file_payload)
            print(self.url + "upload")
            pprint(req.headers)
            print("\n")
            pprint(req.request.headers)
            print("\n")
            pprint(req.request.body)
            print("\n")
            try: 
                res = req.json()["response"][0]
                return res
            except: 
                raise Exception(req.content)
                return req.text
        
    
    # This is a post request that searches TE, Extraction, and AV for the hash. 
    def query(self, file_hash, file_name="example.xls"): 
        print("Querying sandblast for existing entry.")
        
        f = ["te", "extraction"]
        file_type = file_name.split(".")[1]
        print("File type = {}".format(file_type))
        
        hash_type = self.determine_hash_type(file_hash)
        # AV only supports md5
        if hash_type == "md5": 
            f.append("av")
        print(f)
        
        
        if hash_type == None: 
            return "Error - no hash type not sha256, md5, nor sha1 due to hash length being incorrect."
        else: 
            print("Hash type determined to be {}".format(hash_type))
            

        # payload template 
        payload = {
            "request": [
                {
                    "features": f,
                    "file_name": file_name, 
                    "te": {
                        "reports": ["xml", "summary"]
                    },
                    "extraction": {"method":"pdf"}
                }
            ]
        }
        
        # We add the hash value with the appropriate hash type as the key 
        payload["request"][0][hash_type] = file_hash
        
        # We post the request and return the results 
        req = requests.post(url = self.url + "query", headers = self.headers, json=payload) 
        print(req.url)
        try: 
            res = req.json()["response"][0]
            print(res)
            return res 
        except: 
            pprint(req.content)
            pprint(req.status_code)
        
    def download(self): 
        return "Placeholder for download script."
        
    def ping(self):
        self.query("8dfa1440953c3d93daafeae4a5daa326")

#if __name__ == "__main__":
#    print("Checkpoint manager v1")
    
#    sb = SandBlast_Manager(api_key)
    
    # Testing
    # sb.query("8dfa1440953c3d93daafeae4a5daa326")
    
    # test_file = "C:\\Users\\Harrison Parker\\Documents\\testdoc.txt"
#    test_file = "C:/Users/Harrison Parker/Documents/testdoc.txt"

    # sb.upload(test_file, "da855ff838250f45d528a5a05692f14e")
#    sb.upload_v2(test_file)
    
#    exit()
