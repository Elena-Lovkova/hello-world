from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
from SiemplifyUtils import dict_to_flat, add_prefix_to_dict, flat_dict_to_csv, convert_dict_to_json_result_dict
from time import strftime
from SiemplifyDataModel import EntityTypes
from sb_manager import SandBlast_Manager
import requests
import json, base64, os

def dict2str(d):
    if type(d) != dict: return d 
    d_vals = []
    msg = ""
    
    for key, val in d.items(): 
        if type(val) == dict: continue 
        d_vals.append("{}: {}".format(key.replace('_', ' ').capitalize(), str(val)))
        
    return msg + "\n".join(d_vals)


@output_handler
def main():
    siemplify = SiemplifyAction()
    configurations = siemplify.get_configuration('Check Point SandBlast')
    
    api_url = configurations['api_url']
    api_key = configurations['api_key']
    siemplify.script_name = "sb_upload_base64"
    result_value = 'false'
    output_message = ""
    json_result = {}
    error_requests = []
    
    base64_blobs = siemplify.parameters.get("Base64 File Blob")
    max_uploads = int(siemplify.parameters.get("Max Uploads", "5"))
    
    sbmanager = SandBlast_Manager(api_key=api_key, url=api_url)
    
    siemplify.LOGGER.info("----------------- Main - Started -----------------")
    for i, base64_blob in enumerate(base64_blobs.split(",")):
        if i > max_uploads:
            output_message = "Reached maximum uploads."
            break
        base64_blob = base64_blob.strip()
        
        try:
            # file_path = os.path.join(siemplify.run_folder, "temp.txt")
            # with open(file_path, 'wb') as f:
            #     f.write(base64.b64decode(base64_blob))
            # res = sbmanager.upload_old(file_path=file_path)
            res = sbmanager.upload(file_base64=base64_blob, file_name="untitled.doc")
        except Exception as e:
            raise
            error_requests.append(str(e))
            continue
        
        json_result[res.get("file_hash")] = res.get("result")

    if json_result:
        siemplify.result.add_result_json(convert_dict_to_json_result_dict(json_result))
    if error_requests:
        output_message += "\n" + "Errors:\n{}".format("\n".join(error_requests))
    result_value = "true"
    siemplify.LOGGER.info("----------------- Main - Finished -----------------")
    siemplify.end(output_message, result_value)


if __name__ == "__main__":
    main()