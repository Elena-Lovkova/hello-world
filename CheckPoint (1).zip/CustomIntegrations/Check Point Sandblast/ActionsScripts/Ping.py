from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
from SiemplifyUtils import dict_to_flat, add_prefix_to_dict, flat_dict_to_csv, convert_dict_to_json_result_dict
from time import strftime
from SiemplifyDataModel import EntityTypes
from sb_manager import SandBlast_Manager
import requests
import json 
from pprint import pprint 


@output_handler
def main():
    siemplify = SiemplifyAction()
    configurations = siemplify.get_configuration('CheckPoint SandBlast')
    
    api_url = configurations['api_url']
    api_key = configurations['api_key']
    siemplify.script_name = "sb_ping"
    end_state = 'false'
    output_message = ""
    status = EXECUTION_STATE_COMPLETED
    req = None 
    
    sbmanager = SandBlast_Manager(api_key=api_key, url=api_url)
    
    try:
        sbmanager.ping()
        end_state = 'true'
        output_message = "Tested query action for connectivity with sample file hash. No errors."
    except Exception as e: 
        status = EXECUTION_STATE_FAILED
        output_message = str(e)
    


    print("[ INFO ] ----------------- Main - Finished -----------------")
    print("----------------- Main - Finished -----------------")
    print(output_message)
    siemplify.end(output_message, end_state, status)


if __name__ == "__main__":
    main()