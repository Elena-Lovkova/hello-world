from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
from SiemplifyUtils import add_prefix_to_dict, flat_dict_to_csv, convert_dict_to_json_result_dict
from time import strftime
from SiemplifyDataModel import EntityTypes
from sb_manager import SandBlast_Manager
import requests
import json, copy

# CONSTS
SCRIPT_NAME = "sb_query"

def get_unicode(u):
    return str(u)

def dict_to_flat(target_dict):
    """
    Receives nested dictionary and returns it as a flat dictionary.
    :param target_dict: {dict}
    :return: Flat dict : {dict}
    """
    target_dict = copy.deepcopy(target_dict)

    def expand(raw_key, raw_value):
        key = raw_key
        value = raw_value
        """
        :param key: {string}
        :param value: {string}
        :return: Recursive function.
        """
        if value is None:
            return [(get_unicode(key), u"")]
        elif isinstance(value, dict):
            # Handle dict type value
            return [(u"{0}_{1}".format(get_unicode(key),
                                       get_unicode(sub_key)),
                     get_unicode(sub_value)) for sub_key, sub_value in dict_to_flat(value).items()]
        elif isinstance(value, list):
            # Handle list type value
            count = 1
            l = []
            items_to_remove = []
            for value_item in value:
                if isinstance(value_item, dict):
                    # Handle nested dict in list
                    l.extend([(u"{0}_{1}_{2}".format(get_unicode(key),
                                                     get_unicode(count),
                                                     get_unicode(sub_key)),
                               sub_value)
                              for sub_key, sub_value in dict_to_flat(value_item).items()])
                    items_to_remove.append(value_item)
                    count += 1
                elif isinstance(value_item, list):
                    l.extend(expand(get_unicode(key) + u'_' + get_unicode(count), value_item))
                    count += 1
                    items_to_remove.append(value_item)

            for value_item in items_to_remove:
                value.remove(value_item)

            for value_item in value:
                l.extend([(get_unicode(key) + u'_' + get_unicode(count), value_item)])
                count += 1

            return l
        else:
            return [(get_unicode(key), get_unicode(value))]

    items = [item for sub_key, sub_value in target_dict.items() for item in
             expand(sub_key, sub_value)]
    return dict(items)

def dict2str(d):
    if type(d) != dict: return d 
    d_vals = []
    msg = ""
    
    for key, val in d.items(): 
        if type(val) == dict: continue 
        d_vals.append("{}: {}".format(key.replace('_', ' ').capitalize(), str(val)))
        
    return msg + "\n".join(d_vals)
    
def get_feature_name(s): 
    if s == "te": return "Threat Emulation"
    elif s == "av": return "Anti Virus"
    elif s == "extraction": return "Threat Extraction"
    
def get_severity(feature_name, obj):
    if (feature_name == "av"):
        try: 
            return int(obj[feature_name]["malware_info"]["severity"])
        except:
            return 0
    else: 
        return 0 
        
def get_results(feature_name, obj):
    if feature_name == "av": 
        try:  return obj["av"]["malware_info"]
        except: pass
        try: return obj["av"]["status"]
        except: pass
        return {}
    else: 
        try: return obj[feature_name]["status"]
        except: return {}

@output_handler
def main():
    siemplify = SiemplifyAction()
    configurations = siemplify.get_configuration('CheckPoint SandBlast')
    api_url = configurations['api_url']
    api_key = configurations['api_key']
    
    siemplify.script_name = SCRIPT_NAME
    result_value = False
    output_message = "No entities were enriched"
    json_result = {}

    successful_entities = []
    script_directory = siemplify.run_folder
    sb_features = ["te", "av", "extraction"]
    req = None 
    
    sbmanager = SandBlast_Manager(api_key=api_key, url=api_url)
    
    siemplify.LOGGER.info("----------------- Main - Started -----------------")
    
    file_hash = ""
    entity_objs = []
    
    for entity in siemplify.target_entities:
        if entity.entity_type == EntityTypes.FILEHASH: 
            file_hash = entity.identifier
            entity_objs.append(entity)
            
            file_hash = entity.identifier
            file_name = "untitled.doc"
            req = sbmanager.query(file_hash, file_name)
            
            if not req:
                continue
            
            successful_entities.append(entity)
            json_result[entity.identifier] = req
            for feature in sb_features:
                if feature in req.keys():
                    feature_name = get_feature_name(feature)
                    feature_res = get_results(feature, req)
                    
                    insight_text = feature_name.upper() + "\n" + dict2str(feature_res)
                    cp_severity = get_severity(feature, req)
        
                    siemplify.create_case_insight(triggered_by="Checkpoint SandBlast", 
                                                    title=feature_name, 
                                                    content=insight_text,
                                                    severity=0,
                                                    insight_type=1,
                                                    entity_identifier = file_hash
                                                    )
                    if cp_severity > 0 or req[feature].get("combined_verdict") == "malicious":
                        entity.is_suspicious = True
                        result_value = True
                    entity.additional_properties.update(add_prefix_to_dict(dict_to_flat(feature_res), "CP_{}".format(feature_name)))
                    
            
    if successful_entities:
        siemplify.update_entities(successful_entities)
        output_message = "Following entities were enriched:\n{}".format("\n".join([x.identifier for x in successful_entities]))

    siemplify.result.add_result_json(convert_dict_to_json_result_dict(json_result))
    siemplify.end(output_message, result_value)


if __name__ == "__main__":
    main()