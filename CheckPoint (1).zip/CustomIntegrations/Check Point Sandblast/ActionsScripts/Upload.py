from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import unix_now, convert_unixtime_to_datetime, output_handler
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED,EXECUTION_STATE_TIMEDOUT
from SiemplifyUtils import dict_to_flat, add_prefix_to_dict, flat_dict_to_csv, convert_dict_to_json_result_dict
from time import strftime
from SiemplifyDataModel import EntityTypes
from sb_manager import SandBlast_Manager
import requests
import json 

def dict2str(d):
    if type(d) != dict: return d 
    d_vals = []
    msg = ""
    
    for key, val in d.items(): 
        if type(val) == dict: continue 
        d_vals.append("{}: {}".format(key.replace('_', ' ').capitalize(), str(val)))
        
    return msg + "\n".join(d_vals)


@output_handler
def main():
    siemplify = SiemplifyAction()
    configurations = siemplify.get_configuration('Check Point SandBlast')
    
    api_url = configurations['api_url']
    api_key = configurations['api_key']
    siemplify.script_name = "sb_upload"
    end_state = 'false'
    output_message = ""
    successful_entities = []
    script_directory = siemplify.run_folder
    
    file_path = None
    file_hash = None
    
    sbmanager = SandBlast_Manager(api_key=api_key, url=api_url)
    
    siemplify.LOGGER.info("----------------- Main - Started -----------------")
    
    for entity in siemplify.target_entities: 
        siemplify.LOGGER.info(entity.identifier)
        if entity.entity_type == EntityTypes.FILENAME: 
            if not file_path:
                file_path = script_directory + "/" + entity.identifier
        elif entity.entity_type == EntityTypes.FILEHASH: 
            if not file_hash: 
                file_hash = entity.identifier
            if not file_path: 
                continue 
        else: 
            continue
        
        siemplify.LOGGER.info(entity.identifier)
        # Upload to sandblast API 
        try:
            res = sbmanager.upload(file_path=file_path, file_hash=file_hash)
        except Exception as e: 
            # Handle exception - to do 
            res = ""
        if type(res) == str: 
            output_message = "Uploaded file {} to sandblast for analysis".format(file_path)
        else: 
            output_message = "Uploaded file {} to sandblast for analysis".format(file_path)

        successful_entities.append(entity.identifier)
        
    successful_entities = ",".join(successful_entities)
    end_state = "true"
    siemplify.LOGGER.info("----------------- Main - Finished -----------------")
    siemplify.end(output_message + " Successful Entities: {}".format(successful_entities), end_state)


if __name__ == "__main__":
    main()